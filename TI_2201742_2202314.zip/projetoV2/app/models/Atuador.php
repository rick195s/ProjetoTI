<?php

class Atuador extends Device
{


}